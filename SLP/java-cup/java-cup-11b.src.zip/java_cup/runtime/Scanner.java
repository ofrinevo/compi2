package java_cup.runtime;

public abstract interface Scanner
{
  public abstract Symbol next_token()
    throws Exception;
}


/* Location:           E:\TAU\Year3\Compiler\Project\PA02\java-cup\java-cup-11b.jar
 * Qualified Name:     java_cup.runtime.Scanner
 * JD-Core Version:    0.7.0.1
 */