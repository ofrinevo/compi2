package java_cup;

public abstract interface sym
{
  public static final int WITH = 11;
  public static final int CODE_STRING = 35;
  public static final int PARSER = 6;
  public static final int SEMI = 13;
  public static final int INIT = 9;
  public static final int STAR = 15;
  public static final int SCAN = 10;
  public static final int BAR = 19;
  public static final int LT = 29;
  public static final int COMMA = 14;
  public static final int NON = 8;
  public static final int CLASS = 33;
  public static final int CODE = 4;
  public static final int DOT = 16;
  public static final int ID = 34;
  public static final int LEFT = 21;
  public static final int EOF = 0;
  public static final int SUPER = 31;
  public static final int error = 1;
  public static final int START = 12;
  public static final int NONTERMINAL = 27;
  public static final int ACTION = 5;
  public static final int LBRACK = 25;
  public static final int IMPORT = 3;
  public static final int COLON = 17;
  public static final int RBRACK = 26;
  public static final int PACKAGE = 2;
  public static final int NONASSOC = 23;
  public static final int EXTENDS = 32;
  public static final int PRECEDENCE = 20;
  public static final int QUESTION = 30;
  public static final int PERCENT_PREC = 24;
  public static final int TERMINAL = 7;
  public static final int RIGHT = 22;
  public static final int GT = 28;
  public static final int COLON_COLON_EQUALS = 18;
  public static final int NT$3 = 49;
  public static final int empty = 28;
  public static final int NT$2 = 48;
  public static final int NT$1 = 47;
  public static final int NT$0 = 46;
  public static final int package_spec = 1;
  public static final int class_name = 35;
  public static final int precedence_list = 29;
  public static final int wildcard = 45;
  public static final int production_list = 11;
  public static final int action_code_part = 3;
  public static final int production = 21;
  public static final int opt_label = 39;
  public static final int nt_id = 36;
  public static final int parser_code_part = 8;
  public static final int type_id = 18;
  public static final int spec = 0;
  public static final int terminal_id = 40;
  public static final int precedence_l = 32;
  public static final int symbol = 17;
  public static final int import_spec = 13;
  public static final int start_spec = 10;
  public static final int multipart_id = 12;
  public static final int declares_non_term = 34;
  public static final int NT$13 = 59;
  public static final int term_name_list = 19;
  public static final int NT$12 = 58;
  public static final int NT$11 = 57;
  public static final int NT$10 = 56;
  public static final int import_list = 2;
  public static final int init_code = 15;
  public static final int typearguement = 44;
  public static final int code_part = 5;
  public static final int new_non_term_id = 25;
  public static final int declares_term = 33;
  public static final int preced = 30;
  public static final int term_id = 41;
  public static final int rhs = 27;
  public static final int label_id = 38;
  public static final int opt_semi = 6;
  public static final int prod_part_list = 22;
  public static final int robust_id = 42;
  public static final int typearglist = 43;
  public static final int new_term_id = 24;
  public static final int prod_part = 23;
  public static final int code_parts = 4;
  public static final int scan_code = 16;
  public static final int symbol_list = 9;
  public static final int terminal_list = 31;
  public static final int non_term_name_list = 20;
  public static final int import_id = 14;
  public static final int NT$9 = 55;
  public static final int symbol_id = 37;
  public static final int NT$8 = 54;
  public static final int NT$7 = 53;
  public static final int NT$6 = 52;
  public static final int rhs_list = 26;
  public static final int non_terminal = 7;
  public static final int NT$5 = 51;
  public static final int NT$4 = 50;
}


/* Location:           E:\TAU\Year3\Compiler\Project\PA02\java-cup\java-cup-11b.jar
 * Qualified Name:     java_cup.sym
 * JD-Core Version:    0.7.0.1
 */