package java_cup;

public class version
{
  public static final int major = 0;
  public static final int minor = 11;
  public static final String update = "b beta 20140226";
  public static final String version_str = "v0.11b beta 20140226";
  public static final String title_str = "CUP v0.11b 20140808 (SVN rev 54)";
  public static final String author_str = "Scott E. Hudson, Frank Flannery, Michael Petter and C. Scott Ananian";
  public static final String program_name = "java_cup";
}


/* Location:           E:\TAU\Year3\Compiler\Project\PA02\java-cup\java-cup-11b.jar
 * Qualified Name:     java_cup.version
 * JD-Core Version:    0.7.0.1
 */