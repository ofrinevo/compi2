package java_cup;

public class assoc
{
  public static final int left = 0;
  public static final int right = 1;
  public static final int nonassoc = 2;
  public static final int no_prec = -1;
}


/* Location:           E:\TAU\Year3\Compiler\Project\PA02\java-cup\java-cup-11b.jar
 * Qualified Name:     java_cup.assoc
 * JD-Core Version:    0.7.0.1
 */